//NOMBRE DEL ALUMNO: [pon aquí tu nombre]

//RESOLUCIÓN DEL EJERCICIO 2 DEL EXAMEN
(function() {
    //todo tu codigo js aqui
	

})();





