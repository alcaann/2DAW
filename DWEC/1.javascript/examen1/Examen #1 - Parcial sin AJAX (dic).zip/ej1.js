//NOMBRE DEL ALUMNO: [pon aquí tu nombre]

//RESOLUCIÓN DEL EXAMEN
(function() {
    //todo tu codigo js aqui



})();





